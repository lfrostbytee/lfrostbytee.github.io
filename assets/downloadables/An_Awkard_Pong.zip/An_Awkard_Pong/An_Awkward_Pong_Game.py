##Press F5 to run the game!

"""Change the number below if you want the game to be shorter/longer"""
game_time = 60
















"""Try not to touch the stuff below"""

import sys, pygame
import random
pygame.init()

"""Speed"""
base_speed = 10
boost_speed = 20
speed = base_speed
velocity = [speed,speed]
paddle_speed = 10
boost_timer = 50
ball_timer = 100
curr_velocity = int()

"""Color"""
black = (0,0,0)
red = (255,0,0)
blue = (0,0,255)

"""Screen and Clock"""
clock = pygame.time.Clock()
size = width, height = 1000, 1000
screen = pygame.display.set_mode(size)
counter, text = game_time, str(game_time)
pygame.time.set_timer(pygame.USEREVENT, 1000)
font = pygame.font.SysFont('Consolas', 40)


"""Ball"""
ball_x = 500
ball_y = 450
ball = pygame.image.load("cube.jpg")
ballrect = ball.get_rect(topleft = (ball_x,ball_y))


"""Paddle"""
paddle_x = 100
paddle_y = 500
paddle = pygame.image.load("paddle.jpg")
paddlerect = paddle.get_rect(topleft = (paddle_x,paddle_y))
pygame.display.set_caption("An Awkward Pong Game")
pygame.display.set_icon(ball)


"""Boost_Button"""
button_x = 270
button_y = 917
button_ready_image = pygame.image.load("Boost_Ready.png")
button_not_ready_image = pygame.image.load("Boost_Cooldown.png")
buttonrect = pygame.Rect(button_x, button_y, 60,60)


"""Juke Button"""
juke_x = 630
juke_y = 917
juke_ready_image = pygame.image.load("Juke_Ready.png")
juke_cooldown_image = pygame.image.load("Juke_Cooldown.png")
jukerect = pygame.Rect(juke_x, juke_y, 60, 60)


"""Bottom Right_Bar"""
bottom_bar_image = pygame.image.load("Bottom_Bar.jpg")
bottom_bar_rect = pygame.Rect(0,900, 1000,100 )



"""Functions"""
def set_velocity(c_velo): #Accept in a list, current_velocity and an integer, current_speed
    speed_x, speed_y = abs(c_velo[0]), abs(c_velo[1])
    if velocity[0] > 0:
        speed_x = speed_x
    elif velocity[0] < 0:
        speed_x = -speed_x
    if velocity[1] > 0:
        speed_y = speed_y
    elif velocity[1] < 0:
        speed_y = -speed_y
    n_velo = [speed_x,speed_y]
    return n_velo


"""Music and Sound"""
pygame.mixer.init()
Wall_Sound = pygame.mixer.Sound("Wall_Sound.wav")
Paddle_Sound = pygame.mixer.Sound("Paddle_Sound.wav")
Boost_Sound = pygame.mixer.Sound("Boost_Sound_Trim.wav")
Juke_Sound = pygame.mixer.Sound("Juke_Sound.wav")
BG_Music = pygame.mixer.music.load("Awkward_BGM.wav")
pygame.mixer.music.play(loops = 4)

"""Start Screen and End Screen"""
start_screen = pygame.image.load("Start_Screen.jpg")
start_screen_rect = (0,0, 500,500)
player_1_win = pygame.image.load("Player_1_Win.jpg")
player_2_win = pygame.image.load("Player_2_Win.jpg")


##Key_pressed states
boost_state = False
up_state = False
down_state = False
ball_state = False
game_state = False
win_state = int()




#Alter speed here
while True:
    if not game_state:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                break
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    game_state = True
        screen.blit(start_screen, start_screen_rect)
        pygame.display.flip()
        
    else:
        pygame.mixer.music.stop()
        pygame.time.delay(10)
        if counter == 0:
            win_state = 1 #Player 1 wins
            break
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
                break
            
            else:
                if event.type == pygame.USEREVENT:
                    counter -= 1
                    text = str(counter) if counter > 0 else 'End!'
                
                if event.type == pygame.KEYDOWN:
                    pygame.key.get_pressed()
                                
                    if event.key == pygame.K_w:
                        up_state = True
                    if event.key == pygame.K_s:
                        down_state= True
                        
                elif event.type == pygame.KEYUP:
                    if event.key == pygame.K_s:
                        down_state = False
                    elif event.key == pygame.K_w:
                        up_state = False

                if event.type == pygame.MOUSEBUTTONDOWN:
                    if pygame.mouse.get_pressed() == (True,False,False): #M1
                        if not boost_state:
                            boost_state = True
                            curr_velocity = velocity
                            pygame.mixer.Sound.play(Boost_Sound)
                    elif pygame.mouse.get_pressed() == (False,False,True): #M2
                        if not ball_state:
                            ball_state = True
                            pygame.mixer.Sound.play(Juke_Sound)

        if up_state and paddlerect.top > 0:
            paddle_y -= paddle_speed
        if down_state and paddlerect.bottom < height - 100:
            paddle_y += paddle_speed

        """Boost"""
        if boost_state:
            if boost_timer != 0:
                new_velo_x = boost_speed
                new_velo_y = boost_speed
                velocity = set_velocity( (new_velo_x,new_velo_y) )
                boost_timer -= 1
                
            elif boost_timer == 0:
                boost_state = False
                speed = base_speed
                velocity = set_velocity(curr_velocity)
                boost_timer = 50

        """Ball Movement"""
        if ball_state:
            if ball_timer != 0:
                if ball_timer == 100:
                    ballrect.left += 100
                ball_timer -= 1
            elif ball_timer == 0:
                ball_state = False
                ball_timer = 100

            
        """Wall Collision Code"""
        if ballrect.left < 0:
            win_state = 2 #Player 2 wins
            break

        elif ballrect.right > width:
            velocity[0] = -velocity[0]
            velocity[0] += random.randint(-5,5)
            ballrect.right = 999
            pygame.mixer.Sound.play(Wall_Sound)
         
        if ballrect.top < 0:
            velocity[1] = -velocity[1]
            velocity[1] += random.randint(-5,5)
            ballrect.top = 1
            pygame.mixer.Sound.play(Wall_Sound)
            
        elif ballrect.bottom > height - 100:
            velocity[1] = -velocity[1]
            velocity[1] -= random.randint(-5,5)
            ballrect.bottom = height - 100
            pygame.mixer.Sound.play(Wall_Sound)

        """Reset Speed"""
        if velocity[1] == 0 or velocity[1] > 10:
            if not boost_state:
                velocity[1] = base_speed

        if velocity[0] == 0 or velocity[0] > 10:
            if not boost_state:
                velocity[0] = base_speed

            
        """Paddle Collision Code"""       
        if ballrect.left <= paddlerect.right and ballrect.right >= paddlerect.left and ballrect.bottom >= paddlerect.top and ballrect.top <= paddlerect.bottom:          
            velocity[0] = -velocity[0]
            ballrect.left = paddlerect.right + 1
            pygame.mixer.Sound.play(Paddle_Sound)
            
            
        paddlerect = pygame.Rect(paddle_x,paddle_y,50,200)
        ballrect = ballrect.move(velocity)

        """Drawing"""
        screen.fill(black) #Filling BG
        screen.blit(bottom_bar_image, bottom_bar_rect)
        screen.blit(ball, ballrect) #Drawing Ball
        screen.blit(paddle, paddlerect) #Drawing Paddle
        if boost_state:
            screen.blit(button_not_ready_image, buttonrect)
        else:
            screen.blit(button_ready_image, buttonrect)
        
        if ball_state:
            screen.blit(juke_cooldown_image, jukerect)
        else:
            screen.blit(juke_ready_image, jukerect)
        screen.blit(font.render(text, False, (255,255,255)), (900,930))
        pygame.display.flip() #Updating BG
        clock.tick(60) #Limits to max 60FPS

if win_state == 1:
    End_Music = pygame.mixer.music.load("End_BGM_1.wav")
    screen.blit(player_1_win, start_screen_rect)
else:
    End_Music = pygame.mixer.music.load("End_BGM_2.wav")
    screen.blit(player_2_win, start_screen_rect)

pygame.display.flip()
pygame.mixer.music.play()

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
            break
