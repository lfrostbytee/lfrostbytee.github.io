###IMPORTANT###
The game is a Python 3 Executable (So you will need Py3 to run the game)
The user will need to install the pygame package using PIP on Python First!
For further help on the installation, refer to this link here: https://www.pygame.org/wiki/GettingStarted

You can run the game by pressing F5 of you are in the game's code or by default, simply open the .py file!



###NOT IMPORTANT###
Unfortunately, you will need a friend to play this game with... Or you could play it yourself :(
You can change the time taken for the game to end within the Python Script itself!


Sound/Music Library:
Wall-Bounce Sound Effect: mixkit-small-hit-in-a-game-2072
Paddle-Bounce Sound Effect: mixkit-electronic-retro-block-hit-2185
Boost Sound Effect: mixkit-bubbly-achievement-tone-3193 (https://audiotrimmer.com/#google_vignette)
Juke Sound Effect: mixkit-video-game-health-recharge-2837
BGM: Me mashing a bunch of buttons using beepbox.co

In-Game-Sprites are made by me too!


- Made by... Ong Wee, Marcus